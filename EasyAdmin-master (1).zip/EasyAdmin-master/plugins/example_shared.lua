
--[[ This code is disabled as it's an example.

Citizen.CreateThread(function() -- needs to be in a thread.
  permissions["plugin.exmaple"] = false -- adds "easyadmin.plugin.example" Permission which can be used from both the clientside and server side to check for permissions.
end

]]
